package com.paridhi.debuggerapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private static final Integer Intiger = ;
    EditText e1, e2;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=(EditText)findViewById(R.id.edit1);
        e2=(EditText)findViewById(R.id.edit2);
        t1=(TextView)findViewById(R.id.t1);
    }
    public void add(View view){
        int x=Intiger.parseInt(e1.getText().toString());
        int y= Intiger.parseInt(e2.getText().toString());
        int z=x+y;
        t1.setText(""+z);
    }


}
