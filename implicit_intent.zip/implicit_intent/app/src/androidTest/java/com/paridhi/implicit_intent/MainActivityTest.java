package com.paridhi.implicit_intent;

import static org.junit.Assert.*;

public class MainActivityTest {

}